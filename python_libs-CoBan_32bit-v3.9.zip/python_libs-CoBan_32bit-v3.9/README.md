# Install package Python Offline
* Unzip and paste folder <b>python_libs-3.x</b> into Project directory (same level with main.py).
* Open project in Pycharm
* Right click, then choose <b>Run 'setup.py'</b>
When you see this result, the install progress is finished.

```
==================================
Successfully installed packages!!!
```

## Web page
https://www.lfd.uci.edu/~gohlke/pythonlibs/

## Support
Platform: Windows 32bit